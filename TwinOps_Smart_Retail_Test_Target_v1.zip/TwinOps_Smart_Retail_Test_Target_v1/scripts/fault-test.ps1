$base="http://localhost:8090"
# Explicit test: enable delay + controlled failure, request endpoint, inspect observed metrics, disable controls.
Invoke-RestMethod -Method Post -Uri "$base/api/admin/test-controls" -ContentType application/json -Body '{"faultEnabled":true,"faultEvery":2,"delayMs":400}'
1..12 | ForEach-Object { try { Invoke-RestMethod "$base/api/fault-test" | Out-Null } catch { Write-Host "HTTP failure observed" } }
Invoke-RestMethod "$base/twinops/v1/metrics" | ConvertTo-Json -Depth 8
Invoke-RestMethod -Method Post -Uri "$base/api/admin/test-controls" -ContentType application/json -Body '{"faultEnabled":false,"faultEvery":1,"delayMs":0}'
