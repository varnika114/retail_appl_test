# Run while the application is running. Sends real requests and stores real orders.
$base="http://localhost:8090"
1..50 | ForEach-Object { try { Invoke-RestMethod "$base/api/products" | Out-Null } catch {} }
1..20 | ForEach-Object { try { Invoke-RestMethod -Method Post -Uri "$base/api/orders" -ContentType "application/json" -Body '{"product":"Coffee","quantity":1}' | Out-Null } catch {} }
1..30 | ForEach-Object { try { Invoke-RestMethod "$base/api/fault-test" | Out-Null } catch {} }
Invoke-RestMethod "$base/twinops/v1/metrics" | ConvertTo-Json -Depth 8
