package org.twinops.retail;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;
@Component
class DatabaseInitializer {
 private final JdbcTemplate jdbc;DatabaseInitializer(JdbcTemplate j){jdbc=j;}
 @PostConstruct void init(){
  jdbc.execute("CREATE TABLE IF NOT EXISTS products(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL UNIQUE,price DECIMAL(10,2) NOT NULL,stock INT NOT NULL)");
  jdbc.execute("CREATE TABLE IF NOT EXISTS orders(id BIGINT AUTO_INCREMENT PRIMARY KEY,product_id INT NOT NULL,product_name VARCHAR(100) NOT NULL,quantity INT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX idx_orders_created(created_at))");
  Integer count=jdbc.queryForObject("SELECT COUNT(*) FROM products",Integer.class);
  if(count==0){jdbc.update("INSERT INTO products(name,price,stock) VALUES('Coffee',120.00,100),('Notebook',80.00,200),('USB Cable',250.00,50),('Water Bottle',180.00,75),('Pen Pack',40.00,500)");}
 }
}
