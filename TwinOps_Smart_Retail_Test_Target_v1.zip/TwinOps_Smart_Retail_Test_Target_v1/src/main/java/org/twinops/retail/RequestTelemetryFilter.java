package org.twinops.retail;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.stereotype.Component;
import java.io.IOException;
@Component
class RequestTelemetryFilter implements Filter {
 private final TelemetryService telemetry;
 RequestTelemetryFilter(TelemetryService t){telemetry=t;}
 public void doFilter(ServletRequest req,ServletResponse res,FilterChain chain)throws IOException,ServletException{
  HttpServletRequest r=(HttpServletRequest)req;HttpServletResponse s=(HttpServletResponse)res;long start=System.nanoTime();boolean failed=false;String path=r.getRequestURI();
  String area=path.startsWith("/api/orders")?"orders":path.startsWith("/api/products")||path.startsWith("/api/retail")?"retail":"other";
  try{chain.doFilter(req,res);failed=s.getStatus()>=400;}catch(Exception e){failed=true;throw e;}finally{telemetry.record(failed,System.nanoTime()-start,area);}
 }
}
