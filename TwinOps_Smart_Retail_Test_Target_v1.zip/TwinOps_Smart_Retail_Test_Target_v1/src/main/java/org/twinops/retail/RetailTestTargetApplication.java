package org.twinops.retail;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class RetailTestTargetApplication {
 public static void main(String[] args){ SpringApplication.run(RetailTestTargetApplication.class,args); }
}
