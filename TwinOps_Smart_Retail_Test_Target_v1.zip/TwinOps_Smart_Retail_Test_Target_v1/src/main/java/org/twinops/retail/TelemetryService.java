package org.twinops.retail;

import com.zaxxer.hikari.HikariDataSource;
import io.micrometer.core.instrument.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class TelemetryService {
 private final MeterRegistry registry; private final JdbcTemplate jdbc; private final HikariDataSource pool;
 private final long started=System.nanoTime(); private final AtomicLong requests=new AtomicLong(), errors=new AtomicLong();
 private final Timer requestTimer; private final AtomicLong retailCalls=new AtomicLong(), orderCalls=new AtomicLong(), dbCalls=new AtomicLong();
 private final Timer retailTimer, orderTimer, dbTimer;
 private volatile boolean faultEnabled=false; private volatile int delayMs=0; private volatile int faultEvery=0;
 private final AtomicLong faultSequence=new AtomicLong();
 public TelemetryService(MeterRegistry r, JdbcTemplate j, HikariDataSource h){
  registry=r;jdbc=j;pool=h;
  requestTimer=Timer.builder("testtarget.http.request.duration").register(r);
  retailTimer=Timer.builder("testtarget.retail.duration").register(r);
  orderTimer=Timer.builder("testtarget.orders.duration").register(r);
  dbTimer=Timer.builder("testtarget.database.duration").register(r);
  r.gauge("testtarget.http.requests.total",requests);r.gauge("testtarget.http.errors.total",errors);
  r.gauge("testtarget.retail.operations.total",retailCalls);r.gauge("testtarget.orders.operations.total",orderCalls);
  r.gauge("testtarget.database.operations.total",dbCalls);
 }
 public void record(boolean failed,long elapsedNanos,String area){
  requests.incrementAndGet();if(failed)errors.incrementAndGet();requestTimer.record(elapsedNanos,java.util.concurrent.TimeUnit.NANOSECONDS);
  if("retail".equals(area)){retailCalls.incrementAndGet();retailTimer.record(elapsedNanos,java.util.concurrent.TimeUnit.NANOSECONDS);}
  if("orders".equals(area)){orderCalls.incrementAndGet();orderTimer.record(elapsedNanos,java.util.concurrent.TimeUnit.NANOSECONDS);}
 }
 public void recordDb(long nanos){dbCalls.incrementAndGet();dbTimer.record(nanos,java.util.concurrent.TimeUnit.NANOSECONDS);}
 public boolean shouldFault(){return faultEnabled && (faultEvery<=1 || faultSequence.incrementAndGet()%faultEvery==0);}
 public int delay(){return delayMs;}
 public synchronized Map<String,Object> settings(){return Map.of("faultEnabled",faultEnabled,"faultEvery",faultEvery,"delayMs",delayMs);}
 public synchronized Map<String,Object> setSettings(Boolean fault,Integer every,Integer delay){
  if(fault!=null)faultEnabled=fault;if(every!=null){if(every<1||every>10000)throw new IllegalArgumentException("faultEvery must be 1..10000");faultEvery=every;}
  if(delay!=null){if(delay<0||delay>10000)throw new IllegalArgumentException("delayMs must be 0..10000");delayMs=delay;}
  return settings();
 }
 private double cpu(){
  var os=ManagementFactory.getOperatingSystemMXBean();
  if(os instanceof com.sun.management.OperatingSystemMXBean x){double v=x.getCpuLoad();if(v>=0)return v*100;}
  return Double.NaN;
 }
 private double heapPct(){MemoryUsage m=ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();return m.getMax()>0?100.0*m.getUsed()/m.getMax():Double.NaN;}
 private double processMemoryPct(){var os=ManagementFactory.getOperatingSystemMXBean();if(os instanceof com.sun.management.OperatingSystemMXBean x && x.getTotalMemorySize()>0)return 100.0*x.getCommittedMemorySize()/x.getTotalMemorySize();return Double.NaN;}
 private Double finite(double x){return Double.isFinite(x)?x:null;}
 private Map<String,Object> metricsFor(String component, double avail,double cpu,double mem,double latency,double err,double throughput,Double active,Double max,Double dbLat){
  Map<String,Object> m=new LinkedHashMap<>();
  put(m,"availabilityPct",avail);put(m,"cpuPct",cpu);put(m,"memoryPct",mem);put(m,"responseMs",latency);put(m,"errorRatePct",err);put(m,"throughputRps",throughput);put(m,"dbActiveConnections",active);put(m,"dbPoolMax",max);put(m,"dbLatencyMs",dbLat);
  return m;
 }
 private void put(Map<String,Object> m,String k,Double v){if(v!=null&&Double.isFinite(v))m.put(k,v);}
 public Map<String,Object> snapshot(){
  long elapsed=Math.max(1,(System.nanoTime()-started)/1_000_000_000L);
  double total=requests.get(),err=errors.get();
  double rate=total/elapsed,errPct=total==0?0:err*100.0/total;
  Double active=null,max=null,dbLatency=null;
  try{active=pool.getHikariPoolMXBean()==null?null:(double)pool.getHikariPoolMXBean().getActiveConnections();max=(double)pool.getMaximumPoolSize();
   long t=System.nanoTime();jdbc.queryForObject("SELECT 1",Integer.class);long nanos=System.nanoTime()-t;recordDb(nanos);dbLatency=nanos/1_000_000.0;
  }catch(Exception ignored){}
  double cpu=cpu(), heap=heapPct(), mem=processMemoryPct();
  double avg=requestTimer.count()>0?requestTimer.mean(java.util.concurrent.TimeUnit.MILLISECONDS):0;
  Map<String,Object> root=metricsFor("all",100,cpu,heap,avg,errPct,rate,active,max,dbLatency);
  root.put("components",Map.of(
   "RETAIL_API",metricsFor("retail",100,cpu,heap,retailTimer.count()>0?retailTimer.mean(java.util.concurrent.TimeUnit.MILLISECONDS):0,0,retailCalls.get()/elapsed,null,null,null),
   "ORDER_SERVICE",metricsFor("orders",100,cpu,heap,orderTimer.count()>0?orderTimer.mean(java.util.concurrent.TimeUnit.MILLISECONDS):0,0,orderCalls.get()/elapsed,active,max,dbLatency),
   "MYSQL_DATABASE",metricsFor("db",100,Double.NaN,Double.NaN,dbLatency==null?0:dbLatency,0,dbCalls.get()/elapsed,active,max,dbLatency)
  ));
  root.put("sampledAt",Instant.now().toString());root.put("uptimeSeconds",elapsed);root.put("requestsSinceStart",requests.get());root.put("errorsSinceStart",errors.get());
  return root;
 }
}
