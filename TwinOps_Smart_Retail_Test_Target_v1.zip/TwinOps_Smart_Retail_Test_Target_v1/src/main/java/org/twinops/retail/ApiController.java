package org.twinops.retail;

import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.*;
import jakarta.servlet.http.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api")
class ApiController {
 private final JdbcTemplate jdbc; private final TelemetryService telemetry;
 ApiController(JdbcTemplate j,TelemetryService t){jdbc=j;telemetry=t;}
 @GetMapping("/products") List<Map<String,Object>> products(){return jdbc.queryForList("SELECT id,name,price,stock FROM products ORDER BY id");}
 @PostMapping("/orders") ResponseEntity<?> order(@RequestBody Map<String,Object> b){
  String product=String.valueOf(b.getOrDefault("product","Coffee"));int qty=((Number)b.getOrDefault("quantity",1)).intValue();
  if(qty<1||qty>1000)return ResponseEntity.badRequest().body(Map.of("error","quantity must be 1..1000"));
  Integer id=jdbc.queryForObject("SELECT id FROM products WHERE name=?",Integer.class,product);
  if(id==null)return ResponseEntity.badRequest().body(Map.of("error","unknown product"));
  jdbc.update("INSERT INTO orders(product_id,product_name,quantity,created_at) VALUES(?,?,?,NOW())",id,product,qty);
  return ResponseEntity.status(201).body(Map.of("message","order stored in MySQL","product",product,"quantity",qty));
 }
 @GetMapping("/orders") List<Map<String,Object>> orders(){return jdbc.queryForList("SELECT id,product_name,quantity,created_at FROM orders ORDER BY id DESC LIMIT 100");}
 @GetMapping("/retail/summary") Map<String,Object> summary(){
  int products=jdbc.queryForObject("SELECT COUNT(*) FROM products",Integer.class);
  int orders=jdbc.queryForObject("SELECT COUNT(*) FROM orders",Integer.class);
  return Map.of("products",products,"orders",orders);
 }
 @GetMapping("/fault-test") ResponseEntity<?> faultTest() throws InterruptedException {
  if(telemetry.delay()>0)Thread.sleep(telemetry.delay());
  if(telemetry.shouldFault())return ResponseEntity.status(503).body(Map.of("error","test fault enabled","purpose","controlled validation"));
  return ResponseEntity.ok(Map.of("status","OK","message","test endpoint"));
 }
 @GetMapping("/metrics") Map<String,Object> metrics(){return telemetry.snapshot();}
 @PostMapping("/admin/test-controls") Map<String,Object> controls(@RequestBody Map<String,Object> body){
  Boolean fault=body.containsKey("faultEnabled")?(Boolean)body.get("faultEnabled"):null;
  Integer every=body.containsKey("faultEvery")?((Number)body.get("faultEvery")).intValue():null;
  Integer delay=body.containsKey("delayMs")?((Number)body.get("delayMs")).intValue():null;
  return telemetry.setSettings(fault,every,delay);
 }
 @GetMapping("/admin/test-controls") Map<String,Object> getControls(){return telemetry.settings();}
 @GetMapping("/health") Map<String,Object> health(){return Map.of("status","UP","database",jdbc.queryForObject("SELECT 1",Integer.class)==1?"UP":"DOWN");}
 @GetMapping("/test/error") ResponseEntity<?> error(){return ResponseEntity.status(500).body(Map.of("error","intentional test endpoint failure"));}
}
@RestController
class TwinOpsContractController {
 private final TelemetryService telemetry;TwinOpsContractController(TelemetryService t){telemetry=t;}
 @GetMapping("/twinops/v1/metrics") Map<String,Object> metrics(){return telemetry.snapshot();}
 @GetMapping("/twinops/v1/topology") Map<String,Object> topology(){
  return Map.of("components",List.of(
   Map.of("key","RETAIL_API","name","Retail REST API","layer",1,"type","API"),
   Map.of("key","ORDER_SERVICE","name","Order Service","layer",2,"type","SERVICE"),
   Map.of("key","MYSQL_DATABASE","name","MySQL Retail Database","layer",3,"type","DATABASE")),
   "edges",List.of(Map.of("from","RETAIL_API","to","ORDER_SERVICE","label","HTTP/API"),
    Map.of("from","ORDER_SERVICE","to","MYSQL_DATABASE","label","JDBC")));
 }
}
