# TwinOps Smart Retail Test Target v1
A real Spring Boot + MySQL application for validating TwinOps against live measured telemetry. This target does not emit synthetic telemetry. Test controls can intentionally cause real requests to be delayed or return HTTP 503, and these effects are measured by the application's request filter.

## Requirements
- Java 17
- Maven 3.8+
- MySQL Server running locally (the TwinOps test environment has MySQL service installed)
- No Docker required

## 1. Set up database
Open MySQL client or Workbench and run:
```sql
CREATE DATABASE IF NOT EXISTS twinops_retail_test;
```
Use a MySQL account that can create tables in that database. The application defaults to `root` with an empty password only for local setups; override if your MySQL root account uses a password.

## 2. Start app (Windows PowerShell)
From this extracted folder:
```powershell
$env:DB_USER="root"
$env:DB_PASSWORD="YOUR_MYSQL_PASSWORD"
mvn spring-boot:run
```
If local root has no password, set `$env:DB_PASSWORD=""`. Do not share passwords in chat.
App listens on `http://localhost:8090`.

## 3. Confirm basic endpoints (new PowerShell window)
```powershell
Invoke-RestMethod http://localhost:8090/api/health
Invoke-RestMethod http://localhost:8090/api/products
Invoke-RestMethod http://localhost:8090/twinops/v1/metrics
Invoke-RestMethod http://localhost:8090/twinops/v1/topology
```
Metrics values are observed from JVM/process, requests made to this target, Hikari pool, and live `SELECT 1` measurement. Values may be absent where the OS/JVM cannot expose a measurement. Components provide actual operations recorded by this app; component metric fields with no measured basis remain omitted.

## 4. Create genuine traffic
```powershell
# Read product catalog
1..20 | ForEach-Object { Invoke-RestMethod http://localhost:8090/api/products | Out-Null }
# Place actual MySQL-backed orders
1..10 | ForEach-Object { Invoke-RestMethod -Method Post -Uri http://localhost:8090/api/orders -ContentType application/json -Body '{"product":"Coffee","quantity":1}' | Out-Null }
# Test endpoint (real requests)
1..20 | ForEach-Object { Invoke-RestMethod http://localhost:8090/api/fault-test | Out-Null }
# Then re-read metrics
Invoke-RestMethod http://localhost:8090/twinops/v1/metrics | ConvertTo-Json -Depth 8
```
This creates real rows in MySQL and sends actual HTTP requests. Traffic is manually generated for validation, not represented as spontaneous production load.

## 5. Controlled delay / failure validation
First inspect controls:
```powershell
Invoke-RestMethod http://localhost:8090/api/admin/test-controls
```
Enable 250 ms delay and 1-in-3 HTTP 503 fault on `/api/fault-test`:
```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8090/api/admin/test-controls -ContentType application/json -Body '{"faultEnabled":true,"faultEvery":3,"delayMs":250}'
1..15 | ForEach-Object { try { Invoke-RestMethod http://localhost:8090/api/fault-test -ErrorAction Stop | Out-Null } catch { Write-Host "Observed failure: $($_.Exception.Message)" } }
Invoke-RestMethod http://localhost:8090/twinops/v1/metrics | ConvertTo-Json -Depth 8
```
Fault control is **test-only**, explicitly controlled, and only changes the endpoint responses. It does not inject fake metric values. Disable after the test:
```powershell
Invoke-RestMethod -Method Post -Uri http://localhost:8090/api/admin/test-controls -ContentType application/json -Body '{"faultEnabled":false,"faultEvery":1,"delayMs":0}'
```

## 6. Connect TwinOps (HTTP_JSON)
Use TwinOps connector type `HTTP_JSON`, base URL `http://localhost:8090`, auth type `NONE` for local test. Run connector Test, Connect, collect, topology discovery. If TwinOps is on another machine, localhost will not refer to this PC; use an approved reachable host/IP and ensure firewall/network rules are appropriate.

Contract:
- `GET /twinops/v1/metrics` returns measured numeric fields accepted by TwinOps and `components` object with measured component observations.
- `GET /twinops/v1/topology` returns actual application architecture descriptors (application's real API/service/database dependency layout).

## Test coverage guide
- Telemetry: repeatedly sample metrics before/after traffic; compare counters, response-time and rate fields.
- Database: create orders and check the DB active/pool metrics; pool active may be zero between calls because queries are short.
- Topology/component discovery: TwinOps should discover API, Order Service and MySQL Database components and edges.
- Anomaly: produce an observable change in requests/errors/delay and inspect TwinOps anomaly results. An anomaly algorithm may need a history window and sufficient data.
- Prediction: collect genuine samples over time; insufficient history is a valid result, not a test failure.
- What-if: use measured DB pool metrics and explore recommendations without altering live Hikari config.
- Change/rollback: use TwinOps' own change workflow against its supported connector/target configuration. This demo target is not an unrestricted remote config executor.
- Remove Connection: verify TwinOps stops monitoring only this target, preserves its historical records, then reconnect.
- Security: admin test-control endpoints are intentionally local validation controls and are not production hardened. Do not expose this test application to the internet.

## Reset
Stop the app with Ctrl+C. To clear test data (destructive only to this demo DB):
```sql
USE twinops_retail_test;
TRUNCATE TABLE orders;
```
Do not drop the database unless you intend to remove all demo records.
